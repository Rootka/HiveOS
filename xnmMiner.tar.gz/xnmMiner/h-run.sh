./xnmMiner
