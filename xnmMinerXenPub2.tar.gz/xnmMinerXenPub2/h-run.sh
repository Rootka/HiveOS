#!/usr/bin/env bash
set -euo pipefail

MINER_DIR="/hive/miners/custom/xnmMinerXenPub2"
WORKDIR="$MINER_DIR"
URL_DEFAULT="https://xnm.pub/downloads/xenblocks-lin.zip"
BIN="$WORKDIR/xnm-portable.sh"

mkdir -p "$WORKDIR"
cd "$WORKDIR"

URL="${URL_OVERRIDE:-$URL_DEFAULT}"

echo "[xnm-xenblocks] Downloading portable miner from: $URL"
if ! curl -fsSL "$URL" -o "$BIN"; then
  echo "[xnm-xenblocks] ERROR: Download failed: $URL" >&2
  exit 1
fi
chmod +x "$BIN"

CONFIG_FILE="${CUSTOM_CONFIG_FILENAME:-$WORKDIR/xnm-miner.conf}"
if [[ ! -f "$CONFIG_FILE" ]]; then
  echo "[xnm-xenblocks] Creating default config at $CONFIG_FILE"
  cat > "$CONFIG_FILE" <<'EOF'
# Example config for xenblocks miner (fill if your miner uses config files)
# pool = stratum+tcp://POOL_HOST:PORT
# wallet = YOUR_WALLET
# worker = YOUR_WORKER
EOF
fi

echo "[xnm-xenblocks] Starting miner with args: $*"
exec "$BIN" "$@"
