xnmMinerXenPub — HiveOS Custom Miner (fixed layout)
====================================================
Files under xnmMinerXenPub/:
- h-manifest.conf
- h-run.sh
- h-config.sh
- h-stats.sh
