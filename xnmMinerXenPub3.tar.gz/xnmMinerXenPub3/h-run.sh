#!/usr/bin/env bash
set -euo pipefail
: "${CUSTOM_LOG_BASENAME:=xnm-xenblocks}"

# Katalog minera = katalog, w którym leży ten plik
DIR="$(cd -- "$(dirname -- "$(readlink -f -- "$0")")" >/dev/null 2>&1 && pwd -P)"
WORKDIR="$DIR"

URL_DEFAULT="https://xnm.pub/downloads/xenblocks-lin.zip"
BIN="$WORKDIR/xnm-portable.sh"
URL="${URL_OVERRIDE:-$URL_DEFAULT}"

echo "[xnm-xenblocks] Downloading portable miner from: $URL"
if ! curl -fsSL "$URL" -o "$BIN"; then
  echo "[xnm-xenblocks] ERROR: Download failed: $URL" >&2
  exit 1
fi
chmod +x "$BIN"

CONFIG_FILE="${CUSTOM_CONFIG_FILENAME:-$WORKDIR/xnm-miner.conf}"
if [[ ! -f "$CONFIG_FILE" ]]; then
  echo "[xnm-xenblocks] Creating default config at $CONFIG_FILE"
  : > "$CONFIG_FILE"
fi

echo "[xnm-xenblocks] Starting miner with args: $*"
exec bash "$BIN" "$@"
