xnmMinerXenPub2 — HiveOS Custom Miner (ready)
================================================
Folder contents:
- h-manifest.conf
- h-run.sh
- h-config.sh
- h-stats.sh

How it works:
- h-run.sh downloads the portable XenBlocks miner (xenblocks-lin.zip) and executes it,
  passing Flight Sheet 'Extra config arguments' to the miner.
- Override download URL via 'URL_OVERRIDE=...'
