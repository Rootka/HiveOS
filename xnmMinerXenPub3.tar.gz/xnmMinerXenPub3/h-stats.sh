#!/usr/bin/env bash
echo "{}"
exit 0
