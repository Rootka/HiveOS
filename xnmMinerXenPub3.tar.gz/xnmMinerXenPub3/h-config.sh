#!/usr/bin/env bash
set -euo pipefail
: "${CUSTOM_CONFIG_FILENAME:=/hive/miners/custom/xnmMinerXenPub3/xnm-miner.conf}"
mkdir -p "$(dirname "$CUSTOM_CONFIG_FILENAME")"
touch "$CUSTOM_CONFIG_FILENAME"
exit 0
