XNM / XenBlocks — HiveOS Custom Miner Wrapper
================================================

Co to jest?
-----------
Minimalna paczka "Custom Miner" dla HiveOS, która pobiera i uruchamia portable
script z xnm.pub i przekazuje mu argumenty z "Extra config arguments".

Pliki:
- h-manifest.conf : manifest HiveOS
- run.sh          : wrapper pobierający i uruchamiający portable minera

Jak używać w HiveOS:
--------------------
1) Użyj URL do tego ZIP w polu "Installation URL" tworząc Custom miner w Flight Sheet.
2) W "Extra config arguments" wpisz argumenty wymagane przez xenblocksMiner, np.:
   --pool stratum+tcp://POOL_HOST:PORT \
   --wallet WALLET_ADDRESS \
   --worker RIG_NAME \
   --threads 0
3) Zastosuj Flight Sheet i sprawdź logi w /var/log/miner/xnm-xenblocks/

Dodatkowo:
----------
- Możesz nadpisać URL pobierania zmienną URL_OVERRIDE (np. URL_OVERRIDE=https://twoj.serwer/xnm.sh)
