#!/usr/bin/env bash
set -euo pipefail

URL_DEFAULT="https://xnm.pub/downloads/xenblocks-lin.zip"
WORKDIR="/hive/miners/custom/xnm-xenblocks"
BIN="$WORKDIR/xnm-portable.sh"

mkdir -p "$WORKDIR"
cd "$WORKDIR"

URL="${URL_OVERRIDE:-$URL_DEFAULT}"

echo "[xnm-xenblocks] Fetching portable miner from: $URL"
if ! curl -fsSL "$URL" -o "$BIN" ; then
  echo "[xnm-xenblocks] ERROR: Failed to download portable miner from $URL"
  exit 1
fi

chmod +x "$BIN"

echo "[xnm-xenblocks] Starting miner…"
exec "$BIN" "$@"
