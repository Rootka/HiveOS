#!/usr/bin/env bash
set -euo pipefail

# --- Settings ---
URL_DEFAULT="https://xnm.pub/downloads/xenblocks-lin.zip"
WORKDIR="/hive/miners/custom/xnm-xenblocks"
BIN="$WORKDIR/xnm-portable.sh"
CONFIG_FILE="${CUSTOM_CONFIG_FILENAME:-$WORKDIR/xnm-miner.conf}"

mkdir -p "$WORKDIR"
cd "$WORKDIR"

URL="${URL_OVERRIDE:-$URL_DEFAULT}"

echo "[xnm-xenblocks] Fetching portable miner from: $URL"
if ! curl -fsSL "$URL" -o "$BIN" ; then
  echo "[xnm-xenblocks] ERROR: Failed to download portable miner from $URL"
  exit 1
fi

chmod +x "$BIN"

# Jeśli plik konfiguracyjny nie istnieje, stwórz go (może być pusty lub z domyślnymi wartościami)
if [[ ! -f "$CONFIG_FILE" ]]; then
    echo "[xnm-xenblocks] Creating default config file: $CONFIG_FILE"
    # możesz wpisać tutaj domyślne ustawienia, jeśli są potrzebne
    cat > "$CONFIG_FILE" <<EOF
# Domyślny plik konfiguracyjny dla xnm-xenblocks miner
# (jeśli miner wspiera config file)
# Wypełnij pola, jeśli miner ich potrzebuje, np.:
# pool = stratum+tcp://POOL_HOST:PORT
# wallet = YOUR_WALLET
# worker = YOUR_WORKER_NAME
EOF
fi

echo "[xnm-xenblocks] Starting miner…"
/exec "$BIN" "$@"
